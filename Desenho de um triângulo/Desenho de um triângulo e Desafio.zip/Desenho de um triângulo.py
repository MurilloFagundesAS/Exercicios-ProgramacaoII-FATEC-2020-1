for l in range (1, 6):
    for c in range(1, l):
        print(f"X", end="")
    print()