print(f"Programação II -  2º Ciclo Jogos Digitais")
print(f"Nome: Murillo Fagundes  RA: 1430961921013")
print(f"Programa: Python")