soma : int


x = int(input("Digite o primeiro número: "))
y =int(input("Digite o segundo número:"))

soma = x + y
print(f"A soma deu: {soma}")