nome = str(input("Qual o seu nome?"))
print(f"Bem-Vindo, {nome}")